package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.RegisterBean;
import com.cg.dao.RegisterDao;
import com.cg.dao.RegisterDaoImpl;
import com.cg.exception.RegisterException;

public class RegisterServiceImpl implements RegisterService {
	RegisterDao dao;
	public RegisterServiceImpl()
	{
		dao=new RegisterDaoImpl();
	}
	


	@Override
	public ArrayList<RegisterBean> getAllData() throws RegisterException {
		// TODO Auto-generated method stub
		return dao.getAllData();
	}


	@Override
	public int insertCustomer(RegisterBean bean) throws RegisterException {
		// TODO Auto-generated method stub
		return dao.insertCustomer(bean);
	}



	@Override
	public RegisterBean viewCustomer(int id) throws RegisterException {
		// TODO Auto-generated method stub
		return dao.viewCustomer(id);
	}
	

}
