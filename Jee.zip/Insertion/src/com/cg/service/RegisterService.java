package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.RegisterBean;
import com.cg.exception.RegisterException;

public interface RegisterService {
	public int insertCustomer(RegisterBean bean) throws RegisterException;
	ArrayList<RegisterBean> getAllData() throws RegisterException;
	RegisterBean viewCustomer(int id) throws RegisterException;

}
