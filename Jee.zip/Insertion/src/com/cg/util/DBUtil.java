package com.cg.util;


import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.exception.RegisterException;



public class DBUtil {

	static Connection con;
	static String errorMessage;
	static
	{
		try{
			InitialContext context=new InitialContext();
			DataSource source=(DataSource) context.lookup("java:/jdbc/TestDS");
			con=source.getConnection();		
		}
		catch(NamingException | SQLException e)
		{
			try{
			throw new RegisterException(e.getMessage());
			
		}
		catch(RegisterException e1)
		{
			errorMessage=e1.getMessage();
		}
		}
	}
	public static Connection getConnect() 
	{
		return con;
	}

}


