package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.bean.RegisterBean;
import com.cg.exception.RegisterException;
import com.cg.util.DBUtil;

public class RegisterDaoImpl implements RegisterDao{
	Connection con;
	public RegisterDaoImpl()
	{
		con=DBUtil.getConnect();
	}



	@Override
	public int insertCustomer(RegisterBean bean) throws RegisterException {
		// TODO Auto-generated method stub
		
		int id=-1;
		String sql="INSERT INTO REGST VALUES(REGST_SEQ.NEXTVAL,?,?,?,?)";
		try{
		PreparedStatement pst=con.prepareStatement(sql);
		pst.setString(1, bean.getName());
		pst.setString(2, bean.getAddress());
		pst.setString(3, bean.getMobile());
		pst.setString(4, bean.getEmail());
		int result =pst.executeUpdate();
		if(result==0)
		{
			throw new RegisterException("Unable to insert Data");
		}
		String sql1="SELECT REGST_SEQ.CURRVAL FROM DUAL";
		pst=con.prepareStatement(sql1);
		ResultSet rst=pst.executeQuery();
		if(rst.next()){
			id=rst.getInt(1);
		}
		else
		{
			throw new RegisterException("Unable to fetch Sequence");
		}
		}
		catch(SQLException e)
		{
			id=-1;
			throw new RegisterException(e.getMessage());
		}
		
		return id;
	}


	@Override
	public RegisterBean viewCustomer(int id) throws RegisterException {
		// TODO Auto-generated method stub
		RegisterBean bean=new RegisterBean();
		//ArrayList<RegisterBean> list=new ArrayList<RegisterBean>();
		String sql="SELECT ID,NAME,ADDRESS,MOBILE,EMAIL FROM REGST WHERE id=?";
		try{
		PreparedStatement smt=con.prepareStatement(sql);
		smt.setInt(1, id);
		ResultSet rst=smt.executeQuery();
		while(rst.next())
		{
			
			bean.setId(rst.getInt(1));
			bean.setName(rst.getString(2));
			bean.setAddress(rst.getString(3));
			bean.setEmail(rst.getString(4));
			bean.setMobile(rst.getString(5));			
		}
		
		}
		catch(SQLException e)
		{
			
			throw new RegisterException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new RegisterException("Not a valid Id");
		}
		return bean;
	}



	@Override
	public ArrayList<RegisterBean> getAllData() throws RegisterException {
		// TODO Auto-generated method stub
		return null;
	}
	

}
