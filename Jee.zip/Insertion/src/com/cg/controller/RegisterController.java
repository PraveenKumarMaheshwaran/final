package com.cg.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.bean.RegisterBean;
import com.cg.exception.RegisterException;
import com.cg.service.RegisterService;
import com.cg.service.RegisterServiceImpl;

/**
 * Servlet implementation class RegisterController
 */
@WebServlet("*.obj")
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	RegisterService service;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterController() {
       service=new RegisterServiceImpl();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}
		
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RegisterBean bean=null;
		String target="";
		
		HttpSession session=request.getSession(true);
		bean=new RegisterBean();
		int id=0;
		String targetInsert="add.jsp";
		String targetSuccess="success.jsp";
		String targetError="error.jsp";
		String targetView="view.jsp";
		String targetHome="index.jsp";
		String path=request.getServletPath().trim();
		switch(path)
		{
		case "/Home.obj":
			session.setAttribute("error",null);
			session.setAttribute("bean", null);
			target=targetHome;
			break;
		case"/Add.obj":
			
			target=targetInsert;
			break;
		case"/cust.obj":
			String name=request.getParameter("name").trim();
			String address=request.getParameter("address").trim();
			String mobile=request.getParameter("mobile").trim();
			String email=request.getParameter("email").trim();
			
			bean.setId(id);
			bean.setName(name);
			bean.setAddress(address);
			bean.setMobile(mobile);
			bean.setEmail(email);
			try{
			id=service.insertCustomer(bean);
			}
			catch(RegisterException e)
			{
				session.setAttribute("error", e.getMessage());
				target=targetError;
				
			}
			if (id != 0) {
			bean.setId(id);

				// set ID to display ID alone
				// session.setAttribute("donorId", donorId);
				session.setAttribute("bean", bean);
				target = targetSuccess;
			}	
			break;
		case "/view cust.obj":
			target=targetView;
			break;
		case "/search.obj":
			id=Integer.parseInt(request.getParameter("id"));
			try{
			bean=service.viewCustomer(id);
			}
			catch(RegisterException e)
			{
				session.setAttribute("error", e.getMessage());
				target=targetError;
			}
			if (bean.getId() != 0) {
				session.setAttribute("error", null);
				session.setAttribute("bean", bean);
				target = targetView;
			} else {
				session.setAttribute("bean", null);
				session.setAttribute("error",
						"Sorry No data Found for given ID!");
				target = targetError;
			}
			break;

			
			
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher(target);
		dispatcher.forward(request, response);
	}
}
