package com.cg.exception;

public class RegisterException extends Exception{
	String message;
	public RegisterException(String msg)
	{
		this.message=msg;
	}
	@Override
	public String getMessage()
	{
		return message;
	}

}
