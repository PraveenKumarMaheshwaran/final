package com.cg.bean;

public class RegisterBean {

	String name,address,email;
	
	String mobile;

	int id;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public RegisterBean(String name, String address, String email, String mobile,
			int id) {
		super();
		this.name = name;
		this.address = address;
		this.email = email;
		this.mobile = mobile;
		this.id = id;
	}

	public RegisterBean() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "RegisterBean [name=" + name + ", address=" + address
				+ ", email=" + email + ", mobile=" + mobile + ", id=" + id
				+ "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
}
