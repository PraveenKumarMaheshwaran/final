package com.cg.em.bean;

public class EmployeeBean {
	int empId;
	String empName;
	public EmployeeBean(int empId, String empName, int empSal) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
	}
	public EmployeeBean() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "EmployeeBean [empId=" + empId + ", empName=" + empName
				+ ", empSal=" + empSal + "]";
	}
	int empSal;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId2) {
		this.empId = empId2;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpSal() {
		return empSal;
	}
	public void setEmpSal(int empSal) {
		this.empSal = empSal;
	}

}
