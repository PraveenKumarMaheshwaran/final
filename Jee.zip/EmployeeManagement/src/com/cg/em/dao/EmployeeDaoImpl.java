package com.cg.em.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import com.cg.em.bean.EmployeeBean;
import com.cg.em.exception.EmployeeException;
import com.cg.em.util.DBUtil;

public class EmployeeDaoImpl  implements EmployeeDao{
Connection con;
public EmployeeDaoImpl()
{
	con=DBUtil.getConnect();
}
	@Override
	public ArrayList<EmployeeBean> getAllData() throws EmployeeException {
		// TODO Auto-generated method stub
		ArrayList<EmployeeBean> list=new ArrayList<EmployeeBean>();
		String sql="SELECT * FROM EMPDETAILS";
		try{
		Statement smt=con.createStatement();
		ResultSet rst=smt.executeQuery(sql);
		while(rst.next())
		{
			EmployeeBean bean=new EmployeeBean();
			bean.setEmpId(rst.getInt(1));
			bean.setEmpName(rst.getString(2));
			bean.setEmpSal(rst.getInt(3));
			list.add(bean);
		}
		if(list.size()==0) throw new EmployeeException("No data Found");
		}
		catch(SQLException e)
		{
			throw new EmployeeException(e.getMessage());
		}
	
		
		
		return list;
	}

	@Override
	public EmployeeBean updateSalary(int empId, int salary)
			throws EmployeeException {
		// TODO Auto-generated method stub
		EmployeeBean emp=ValidateEmployee(empId);
		if(emp!=null)
		{
			String sql="UPDATE EMPDETAILS SET EMPSAL=? WHERE EMPID=?";
			try{
				PreparedStatement pst=con.prepareStatement(sql);
				pst.setInt(1, salary);
				pst.setInt(2, empId);
				int row=pst.executeUpdate();
				if(row==1)
				{
					emp.setEmpSal(salary);
				}
				else{
					throw new EmployeeException("unable to update salary");
				}
			}
				catch(SQLException e)
				{
					throw new EmployeeException(e.getMessage());
				}
			
		}
	
		return emp;
	}
	public EmployeeBean ValidateEmployee(int empId)throws EmployeeException
	{
		EmployeeBean emp=null;
		String sql="SELECT *FROM EMPDETAILS WHERE EMPID=?";
		try{
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, empId);
			ResultSet rst=pst.executeQuery();
			if(rst.next())
			{
				emp=new EmployeeBean();
				emp.setEmpId(rst.getInt(1));
				emp.setEmpName(rst.getString(2));
				emp.setEmpSal(rst.getInt(3));
			
			}
			
		}
		catch(SQLException e)
		{
			throw new EmployeeException(e.getMessage());
		}
		return emp;
	}
	@Override
	public EmployeeBean deleteEmp(int empId) throws EmployeeException {
		// TODO Auto-generated method stub
		EmployeeBean bean=new EmployeeBean();
		
		String sql="DELETE FROM EMPDETAILS WHERE EMPID=?";
		try{
		PreparedStatement smt=con.prepareStatement(sql);
		smt.setInt(1, empId);
		int row=smt.executeUpdate();
		if(row==1)
		{
			bean.setEmpId(empId);
		}
		else{
			throw new EmployeeException("unable to update salary");
		}
	}
		catch(SQLException e)
		{
			throw new EmployeeException(e.getMessage());
		}
		
		return bean;
	}
	

}
