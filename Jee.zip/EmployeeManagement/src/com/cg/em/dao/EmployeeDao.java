package com.cg.em.dao;

import java.util.ArrayList;

import com.cg.em.bean.EmployeeBean;
import com.cg.em.exception.EmployeeException;

public interface EmployeeDao {
	ArrayList<EmployeeBean> getAllData() throws EmployeeException;
	EmployeeBean updateSalary(int empId,int salary)throws EmployeeException;
	EmployeeBean deleteEmp(int empId)throws EmployeeException;

}
