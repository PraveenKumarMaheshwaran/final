package com.cg.rf.exception;

public class RFException extends Exception{
	 String message;
	 public RFException(String msg){
		 this.message = msg;
	 }
	 @Override
	   public String getMessage(){
		  return message;
	  }

}
