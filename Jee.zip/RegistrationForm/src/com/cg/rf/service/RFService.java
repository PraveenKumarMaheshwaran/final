package com.cg.rf.service;

import com.cg.rf.bean.RFBean;
import com.cg.rf.exception.RFException;

public interface RFService {
		int addCust(RFBean bean) throws RFException;
		RFBean showcustById(int custid) throws RFException;
}
