package com.cg.rf.service;

import com.cg.rf.bean.RFBean;
import com.cg.rf.dao.RFDao;
import com.cg.rf.dao.RFDaoImpl;
import com.cg.rf.exception.RFException;

public class RFServiceImpl implements RFService{
	RFDao dao = new RFDaoImpl();
	@Override
	public int addCust(RFBean bean) throws RFException {
		// TODO Auto-generated method stub
		return dao.addCust(bean);
	}

	@Override
	public RFBean showcustById(int custid) throws RFException {
		// TODO Auto-generated method stub
		return dao.showcustById(custid);
	}

}
