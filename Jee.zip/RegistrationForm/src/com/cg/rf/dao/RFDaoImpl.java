package com.cg.rf.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.rf.bean.RFBean;
import com.cg.rf.exception.RFException;
import com.cg.rf.util.DBUtil;

public class RFDaoImpl implements RFDao{
	Connection con =DBUtil.getConnect();

	@Override
	public int addCust(RFBean bean) throws RFException {
		// TODO Auto-generated method stub
		int custid = 1;
		String sql = "INSERT INTO customers VALUES(cust.nextval,?,?,?,?)";
		String sql1 = "SELECT cust.currval FROM DUAL";
		try{
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, bean.getCustname());
		pstmt.setString(2, bean.getCustaddress());
		pstmt.setString(3, bean.getPhoneno());
		pstmt.setString(4, bean.getEmail());
		int res = pstmt.executeUpdate();
		if(res==0){
			throw new RFException("insert failed");
		}
		PreparedStatement pstmt1 = con.prepareStatement(sql1);
		ResultSet rst = pstmt1.executeQuery();
		if(rst.next()){
			custid = rst.getInt(1);
		}else{
			throw new RFException("unable to generate sequence");
		}
		}catch(SQLException e){
			throw new RFException(e.getMessage());
		}
		
		return custid;
	}

	@Override
	public RFBean showcustById(int custid) throws RFException {
		// TODO Auto-generated method stub
		RFBean bean = new RFBean();
		String sql = "SELECT * FROM customers where custid=?";
		try{
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1,custid);
			ResultSet rst = pstmt.executeQuery();
			if(rst.next()){
				bean.setCustid(rst.getInt(1));
				bean.setCustname(rst.getString(2));
				bean.setCustaddress(rst.getString(3));
				bean.setPhoneno(rst.getString(4));
				bean.setEmail(rst.getString(5));
			}else{
				throw new RFException("ID does not Exist");
			}
			
		}catch(SQLException e){
			throw new RFException(e.getMessage());
		}
		System.out.println(bean);
		return bean;
	}

}
