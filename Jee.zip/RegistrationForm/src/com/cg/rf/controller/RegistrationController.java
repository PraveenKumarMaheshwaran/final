package com.cg.rf.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.rf.bean.RFBean;
import com.cg.rf.exception.RFException;
import com.cg.rf.service.RFService;
import com.cg.rf.service.RFServiceImpl;

/**
 * Servlet implementation class RegistrationController
 */
@WebServlet("/RegistrationController")
public class RegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       RFService service = new RFServiceImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession(true);
		RFBean bean = new RFBean();
		PrintWriter out = response.getWriter();
		String name= request.getParameter("name");
		String address= request.getParameter("add");
		String pno= request.getParameter("phone");
		String email= request.getParameter("mail");
		bean.setCustname(name);
		bean.setCustaddress(address);
		bean.setPhoneno(pno);
		bean.setEmail(email);
		try {
			int id = service.addCust(bean);
			bean.setCustid(id);
			if(bean!=null){
				session.setAttribute("id", id);
				session.setAttribute("bean", bean);
				 response.sendRedirect("success.jsp");
			}
		} catch (RFException e) {
			  session.setAttribute("error", e.getMessage());
			    response.sendRedirect("error.jsp");
		}
		
		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession(true);
		String id= request.getParameter("id");
		int custid = Integer.parseInt(id);
		session.setAttribute("id", custid);
		try {
			RFBean bean = service.showcustById(custid);
			if(bean!=null){

				session.setAttribute("bean", bean);     
				response.sendRedirect("showdetails.jsp");
			}
		} catch (RFException e) {
			// TODO Auto-generated catch block
			session.setAttribute("error", e.getMessage());
		    response.sendRedirect("error.jsp");
		
		}
	}
	}


