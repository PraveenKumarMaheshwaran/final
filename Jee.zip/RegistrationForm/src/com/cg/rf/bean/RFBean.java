package com.cg.rf.bean;

public class RFBean {
		@Override
	public String toString() {
		return "RFBean [custid=" + custid + ", custname=" + custname
				+ ", custaddress=" + custaddress + ", phoneno=" + phoneno
				+ ", email=" + email + "]";
	}
		int custid;
		String custname;
		String custaddress;
		String phoneno;
		String email;
		public int getCustid() {
			return custid;
		}
		public void setCustid(int custid) {
			this.custid = custid;
		}
		public String getCustname() {
			return custname;
		}
		public void setCustname(String custname) {
			this.custname = custname;
		}
		public String getCustaddress() {
			return custaddress;
		}
		public void setCustaddress(String custaddress) {
			this.custaddress = custaddress;
		}
		public String getPhoneno() {
			return phoneno;
		}
		public void setPhoneno(String phoneno) {
			this.phoneno = phoneno;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
}
