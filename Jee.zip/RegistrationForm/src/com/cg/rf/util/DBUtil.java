package com.cg.rf.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.rf.exception.RFException;

public class DBUtil {
	static Connection con;
	private static String errorMessage;
	static
	{
		try {
			InitialContext context = new InitialContext();
			DataSource source =
					(DataSource)context.lookup("java:/jdbc/TestDS");
				con = source.getConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				try {
					throw new RFException(e.getMessage());
				} catch (RFException e1) {
					// TODO Auto-generated catch block
					errorMessage = e1.getMessage();
				}
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			try {
				throw new RFException(e.getMessage());
			} catch (RFException e1) {
				// TODO Auto-generated catch block
				errorMessage = e1.getMessage();
			}
		}
	}
		 public  static Connection getConnect()
		    {
		    	return con;
		    }
	
}


